﻿using System.IO;
using System.Linq;
using System.Data.Entity;
using System.Net;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using Food.Data;
using Food.Models; 
namespace Food.Controllers
{
    public class HomeController : Controller
    {
        private CompaniesEntities db = new CompaniesEntities();
        private compProducts companyProducts = new compProducts();
        public ActionResult Index()
        {
            var companies = db.Companies.Include(c => c.CompanyType).Include(c => c.CompanyPrice).Include(c => c.CompanyRating);

            return View(companies.ToList());
        }

        // GET
        public ActionResult companypage(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            companyProducts.PassCompanyID = id;

            companyProducts.comp = (from p in db.Companies
                                    where p.Id == id
                                    select p);
            companyProducts.Products = (from p in db.CompanyProducts
                                        where p.CompanyID == id
                                        select p.Product).Include(x => x.ProductCode1);   
            return View(companyProducts);
        }

        [HttpPost]
        public ActionResult companypage([Bind(Include = "ProductName,ProductID")]compProducts products)
        {
             

                //      return RedirectToAction("cart");



                return View();
        }

    }
}